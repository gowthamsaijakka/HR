﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SqlLibrary.Models
{
    public class AccountsAndStatutory
    {
        public static AccountsAndStatutory id;

        [Key]
        public int EmployeeId { get; set; }
        public string BankName { get; set; }
        public string BankAccountNumber { get; set; }
        public string BankIfscCode { get; set; }
        public string BankBranch { get; set; }
        public string PermanentAccountNumber { get; set; }

        public static void Add(AccountsAndStatutory value)
        {
            throw new NotImplementedException();
        }

        public static void Remove(int id)
        {
            throw new NotImplementedException();
        }
    }
}

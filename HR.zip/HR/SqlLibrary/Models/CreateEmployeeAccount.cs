﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SqlLibrary.Models
{
    public class CreateEmployeeAccount
    {
        [Key]
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int PhoneNumber { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string Qualification { get; set; }
        public string Skills { get; set; }
        public string Department { get; set; }
        public DateTime DateOfJoining { get; set; }
        public string Address { get; set; }
        public string EmployeeImage { get; set; }
    }
}

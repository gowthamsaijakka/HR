﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SqlLibrary.Models
{
    public class LoginAuthentication
    {
        [Key]
        public int EmployeeId { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }
}

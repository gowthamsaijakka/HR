﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SqlLibrary.Models
{
    public class MeetingSchedule
    {
        [Key]
        public String Title { get; set; }
        public string EmployeeName { get; set; }
        public TimeSpan Time { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan MeetingDuration { get; set; }
        public String Location { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SqlLibrary.Models
{
    public class EmployeeSalaryDetails
    {
        [Key]
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public Double Salary { get; set; }
        public String Payslips { get; set; }
    }
}

﻿using SqlLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace SqlLibrary
{
    public class VioletContext : DbContext
    {
        public VioletContext()
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=162.222.225.88;Initial Catalog=Violet;Persist Security Info=True;User ID=DBA;Password=Nagaraju@456;Encrypt=True;TrustServerCertificate=True");
        }  

        public virtual DbSet<EmployeeDetails> EmployeeDetails { get; set; }
        public virtual DbSet<OnboardingChart> OnboardingChart { get; set; }
        public virtual DbSet<EmployeeLeaves> EmployeeLeaves { get; set; }
        public virtual DbSet<AccountsAndStatutory> AccountsAndStatutory { get; set; }
        public virtual DbSet<EmployeeSalaryDetails> EmployeeSalaryDetails { get; set; }
        public virtual DbSet<LoginAuthentication> LoginAuthentication { get; set; }
        public virtual DbSet<MeetingSchedule> MeetingSchedule { get; set; }
        public virtual DbSet<CreateEmployeeAccount> CreateEmployeeAccount { get; set; }
    }
   
}

﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeSalaryDetailsController : ControllerBase
    {
        private readonly VioletContext _vc;
        public EmployeeSalaryDetailsController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<EmployeeSalaryDetailsController>
        [HttpGet]
        public IEnumerable<EmployeeSalaryDetails> Get()
        {
            return _vc.EmployeeSalaryDetails.ToList<EmployeeSalaryDetails>();
        }

        // POST api/<EmployeeSalaryDetailsController>
        [HttpPost]
        public void Post([FromBody] EmployeeSalaryDetails value)
        {
            _vc.EmployeeSalaryDetails.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<EmployeeSalaryDetailsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] EmployeeSalaryDetails value)
        {
            _vc.id = value;
            _vc.SaveChanges();
        }

        // DELETE api/<EmployeeSalaryDetailsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _vc.Remove(id);
            _vc.SaveChanges();
        }
    }
}

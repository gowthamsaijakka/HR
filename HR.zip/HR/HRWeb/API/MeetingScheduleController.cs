﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeetingScheduleController : ControllerBase
    {
        private readonly VioletContext _vc;
        public MeetingScheduleController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<MeetingScheduleController>
        [HttpGet]
        public IEnumerable<MeetingSchedule> Get()
        {
            return _vc.MeetingSchedule.ToList<MeetingSchedule>();
        }

        // POST api/<MeetingScheduleController>
        [HttpPost]
        public void Post([FromBody] MeetingSchedule value)
        {
            _vc.MeetingSchedule.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<MeetingScheduleController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] MeetingSchedule value)
        {
            _vc.id = value;
            _vc.SaveChanges();
        }

        // DELETE api/<MeetingScheduleController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _vc.Remove(id);
            _vc.SaveChanges();
        }
    }
}

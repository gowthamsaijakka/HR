﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class CreateEmployeeAccountController : ControllerBase
    {
        private readonly VioletContext _vc;
        public CreateEmployeeAccountController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<CreateEmployeeAccountController>
        [HttpGet]
        public IEnumerable<CreateEmployeeAccount> Get()
        {
            return _vc.CreateEmployeeAccount.ToList<CreateEmployeeAccount>();
        }

        // POST api/<CreateEmployeeAccountController>
        [HttpPost]
        public void Post([FromBody] CreateEmployeeAccount value)
        {
            _vc.CreateEmployeeAccount.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<CreateEmployeeAccountController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] CreateEmployeeAccount value)
        {
            _vc.CreateEmployeeAccount.id = value;
            _vc.SaveChanges();
        }

        // DELETE api/<CreateEmployeeAccountController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
             _vc.Remove(id);
             _vc.SaveChanges();
        }
    }
}

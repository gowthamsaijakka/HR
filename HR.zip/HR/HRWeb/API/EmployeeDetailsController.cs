﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDetailsController : ControllerBase
    {
        private readonly VioletContext _vc;
        public EmployeeDetailsController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<EmployeeDetailsController>
        [HttpGet]
        public IEnumerable<EmployeeDetails> Get()
        {
            return _vc.EmployeeDetails.ToList<EmployeeDetails>();
        }

        // POST api/<EmployeeDetailsController>
        [HttpPost]
        public void Post([FromBody] EmployeeDetails value)
        {
            _vc.EmployeeDetails.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<EmployeeDetailsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] EmployeeDetails value)
        {
            _vc.EmployeeDetails.id = value;
            _vc.SaveChanges();
        }

        // DELETE api/<EmployeeDetailsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _vc.Remove(id);
            _vc.SaveChanges();
        }
    }
}

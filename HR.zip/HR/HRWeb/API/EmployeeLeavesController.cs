﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeLeavesController : ControllerBase
    {
        private readonly VioletContext _vc;
        public EmployeeLeavesController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<EmployeeLeavesController>
        [HttpGet]
        public IEnumerable<EmployeeLeaves> Get()
        {
            return _vc.EmployeeLeaves.ToList<EmployeeLeaves>();
        }

        // POST api/<EmployeeLeavesController>
        [HttpPost]
        public void Post([FromBody] EmployeeLeaves value)
        {
            _vc.EmployeeLeaves.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<EmployeeLeavesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] EmployeeLeaves value)
        {
            _vc.id= value;
            _vc.SaveChanges();
        }

        // DELETE api/<EmployeeLeavesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _vc.Remove(id);
            _vc.SaveChanges();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class OnboardingChartController : ControllerBase
    {
        private readonly VioletContext _vc;
        public OnboardingChartController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<ValuesController>
        [HttpGet]
        public IEnumerable<OnboardingChart> Get()
        {
            return _vc.OnboardingChart.ToList<OnboardingChart>();
        }

        // POST api/<ValuesController>
        [HttpPost]
        public void Post([FromBody] OnboardingChart value)
        {
            _vc.OnboardingChart.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] OnboardingChart value)
        {
            _vc.OnboardingChart.id = value;
            _vc.SaveChanges();
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _vc.Remove(id);
            _vc.SaveChanges();
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using SqlLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SqlLibrary;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HRWeb.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsAndStatutoryController : ControllerBase
    {
        private readonly VioletContext _vc;
        public AccountsAndStatutoryController(VioletContext vc)
        {
            _vc = vc;
        }
        // GET: api/<AccountsAndStatutoryController>
        [HttpGet]
        public IEnumerable<AccountsAndStatutory> Get()
        {
            return _vc.AccountsAndStatutory.ToList(); 
        }

        // POST api/<AccountsAndStatutoryController>
        [HttpPost]
        public void Post([FromBody] AccountsAndStatutory value)
        {
            AccountsAndStatutory.Add(value);
            _vc.SaveChanges();
        }

        // PUT api/<AccountsAndStatutoryController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] AccountsAndStatutory value)
        {
            AccountsAndStatutory.id = value;
            _vc.SaveChanges();
         
        }

        // DELETE api/<AccountsAndStatutoryController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            AccountsAndStatutory.Remove(id);
            _vc.SaveChanges();
         
        }
    }
}
